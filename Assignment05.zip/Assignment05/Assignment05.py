# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Phantasia Mayner
# Date:  April 29, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Phantasia Mayner>, 4/29/2019, Added code to complete assignment 5
# -------------------------------------------------#


# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
objFile = open("ToDo.txt", "r")
strData = objFile.read()
objFile.close()
lstTable = []


for line in strData.splitlines():
    stringValues = line.split(",")
    dictRow = {"Task":stringValues[0], "Priority":stringValues[1]}
    lstTable.append(dictRow)


# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data.
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File.
    5) Exit Program.
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        for dictRow in lstTable:
            print("Task: ", dictRow["Task"], ",", "Priority: ", dictRow["Priority"])
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        taskName = input("\nEnter a Task: ")
        priorityName = input("\nEnter the task's Priority: ")
        dictNewRow = {"Task": taskName, "Priority": priorityName}
        lstTable.append(dictNewRow)
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        taskName = input("\nEnter the Task you wish to remove: ")
        for dictRow in lstTable:
            if taskName == dictRow["Task"]:
                lstTable.remove(dictRow)
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objFile = open("ToDo.txt", "w")

        for dictRow in lstTable:
          objFile.write(dictRow["Task"] + "," + dictRow["Priority"] + "\n")

        objFile.close()
        print("Your tasks have been saved!")
        continue

    elif (strChoice == '5'):
        break
         # and Exit the program
