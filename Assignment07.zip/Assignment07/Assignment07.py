# ........................................................#
# Title: Simple Exception Handling and Pickling
# Desc: A simple way to handle exceptions and pickling
# a list of data
# Change Log: (PMayner, 2019-05-13, added additional comments)
# PMayner,2019-05-12,Created File
# ........................................................#


# A simple example of how you would use Python Exception Handling
# Ask for numerical input from user(trapping with a try statement)
try:
    numericalValue = float(input("Please enter a numerical value: "))
# in the event that the user does not input a number, create an exception
except ValueError:
    print("Oops! You did not enter a number.\n")
# create an else statement if user does provide valid input
else:
    print("Yes! That was a number. You entered ", numericalValue, "\n")

# create a simple example of how you would use Python Pickling
# must import the pickle function
import pickle
# provide data to be saved to file
species = ["Python", "Anaconda", "Viper"]
locations = ["Rain Forest", "Desert", "Tundra"]
famous = ["Sir Hiss", "Kaa", "Nagini"]
# open file that data will be pickled to
pickleFile = open("pickledSnakes.dat", "wb")
# "dump" data to file
pickle.dump(species, pickleFile)
pickle.dump(locations, pickleFile)
pickle.dump(famous, pickleFile)
# close file
pickleFile.close()
# state that data has been pickled
print("Snakes have been pickled.")
# provide Exit to user
input("\n\nPress the Enter key to exit...")