# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Phantasia Mayner
# Date:  May 5, 2019
# ChangeLog: (Who, When, What)
# -------------------------------------------------#

# ------ Data ------
# lstTable to hold, display, add, remove, and save values pertaining to .txt
lstTable = []
textFile = "ToDo.txt"

# -----Process -----
class TaskProcessor():
    """This class contains methods to get, show, add, remove, and save data from ToDo.txt"""

    # generate data from file
    @staticmethod
    def GetData():
        objFile = open(textFile, "r")
        strData = objFile.read()
        objFile.close()

        for line in strData.splitlines():
            stringValues = line.split(",")
            dictRow = {"Task": stringValues[0], "Priority": stringValues[1]}
            lstTable.append(dictRow)

    # current data
    @staticmethod
    def ShowData():
            for dictRow in lstTable:
                print("Task: ", dictRow["Task"], ",", "Priority: ", dictRow["Priority"])

    # add new item
    @staticmethod
    def AddItem(taskName, priorityName):
        dictNewRow = {"Task": taskName, "Priority": priorityName}
        lstTable.append(dictNewRow)

    # remove item
    @staticmethod
    def RemoveItem(taskName):
        found = False
        for dictRow in lstTable:
            if taskName == dictRow["Task"]:
                lstTable.remove(dictRow)
                found = True
                return found


    # save data to file
    @staticmethod
    def SaveData():
        objFile = open(textFile, "w")
        for dictRow in lstTable:
            objFile.write(dictRow["Task"] + "," + dictRow["Priority"] + "\n")
        objFile.close()

# ------ Presentation ------
# Step 2 - Display a menu of choices to the user

# Retrieve data from ToDo.txt
TaskProcessor.GetData()

while (True):
    print("""
    Menu of Options
    1) Show current data.
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File.
    5) Exit Program.
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        TaskProcessor.ShowData()
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        taskName = input("\nEnter a Task: ")
        priorityName = input("\nEnter the task's Priority: ")
        TaskProcessor.AddItem(taskName, priorityName)
        print("\nYour new task has been added!\n")
        TaskProcessor.ShowData()
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        taskName = input("\nEnter the Task you wish to remove: ")

        # returns either true or false
        isItemFound = TaskProcessor.RemoveItem(taskName)

        if (isItemFound == True):
            print("\nYour task has been removed\n")
        else:
            print ("\nYour task could not be found\n")

        TaskProcessor.ShowData()
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        TaskProcessor.SaveData()
        print("Your tasks have been saved!")
        continue

    elif (strChoice == '5'):
        break
         # and Exit the program
